# PulseSesorAmped_Hardware
These files were created in [Design Spark](http://www.designspark.com/) Schematic Layout and PCB Capture Software 

You will need to copy the contents of DesignSparkLibraryFiles into the default Library that Design Spark uses. Normally something like 

`Documents\DesignSpark PCB\Library`

This is the only way you will be able to use or modify the APDS-9008 part or the reverse mount LED part.


CONTRIBUTORS BACKTRACK AND NOTIFICATION

joel@pulsesensor.com
yury@pulsesensor.com

