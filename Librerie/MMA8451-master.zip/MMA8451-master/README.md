Name : MMA8451_n0m1 Library
Author : Noah Shibley, Michael Grant, NoMi Design Ltd. http://n0m1.com, modified for MMA8451 by bilbolodz bilbo@lodz.pl
Date : Feb 10th 2012
Version : 0.1
Notes : Arduino Library for use with the Freescale MMA8453Q via i2c.
          Some of the lib source from Kerry D. Wong
http://www.kerrywong.com/2012/01/09/interfacing-mma8453q-with-arduino/
This library has been tested with the Freescale MMA8453Q Accelerometer
chip, however the Freescale MMA8451, and MMA8452 probably also work.
Refer to the examples for how to use this library. 
